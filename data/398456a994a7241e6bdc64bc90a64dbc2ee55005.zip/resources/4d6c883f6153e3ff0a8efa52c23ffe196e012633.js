import ecore_get_api from './ecore_bindings.js';
import getWasm from './libengine_core.js';

const config_g1_and_g2 = `{
  "version"                  : "1.0.0",
  "info"                     : "",
  "generation"               : 1,

  "# Encoder AND Decoder"    : "- - -",
  "freq_channel_0"           : 17532.0,
  "carriers" : {
      "audible" : { "freq_channel_0" : 10000.0 },
      "ultra"   : { "freq_channel_0" : 17532.0 }
  },
  "channel_spacing_Hz"       : 187.5,

  "nChannels"                : 11,
  "nOnes"                    : 5,

  "symbols_per_trigger"      : 3,

  "calib_symbol"             : false,

  "duration_ms"              : 100,
  "silence_ms"               : 200,       "# silence-between-symbols N/A when 1 symbol!" : "",

  "# Encoder ONLY"           : "- - -",
  "fat_symbols"              : false,
  "encoder_sample_rate"      : 48000,
  "ramp_ms"                  : 20,         "# ramp takes from duration's timeslice" : "",

  "# Decoder ONLY"           : "- - -",
  "decoder_sample_rate"      : 48000,

  "fftOrder"                 : 11,
  "xoverlap"                 : 4,

  "avgHistory"               : 10,
  "windowBeta"               : 8.0,

  "thresh_ratio"             : 0.8,

  "thresh_sig_strength"      : 0.9,

  "report_probs"             : [1, 0, 0, 0],        "# DEPRECATED: only used for engine < 1.16; we try to minimize report-sending here": "",
  "report_dist"              : [500, 95, 5, 2, 1],  "# { NO REPORT | triggers | trigger-frames | trace | wav }": "",

  "disable_nearest_match"    : true,
  "report_spread_ms"         : 15000,

  "custom_report_ms"         : 3000,
  "custom_report_prob"       : 0.1,

  "intersymbol_tol"          : 0.3,
  "custom_report_trigger"    : "0.1.2",

  "disable_calib"            : true,

  "generation"               : 1,
  "decoder_sync_mode_active" : true,

  "g2_report_in_g1"          : false,
  "g2_callback_in_g1"        : true,
  "g2_freq_channel_0"        : 18500
}`;

const run_engine = (ecore) => {
  ecore.init('', config_g1_and_g2);
  ecore.set_receiver_callback((json_string) => {
    postMessage(json_string);
  });
};

(async () => {
  const Module = await getWasm();
  const ecore = ecore_get_api(Module);

  onmessage = function ({ data }) {
    ecore.feed(data.buf, data.buf.length, data.sRate);
  };

  run_engine(ecore);
})();
